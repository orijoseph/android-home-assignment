package homework.chegg.com.chegghomework.features

import android.annotation.SuppressLint
import android.arch.lifecycle.ViewModel
import android.util.Log
import homework.chegg.com.chegghomework.data.IDetailsTiDisplay
import homework.chegg.com.chegghomework.data.ResponseA
import homework.chegg.com.chegghomework.data.ResponseB
import homework.chegg.com.chegghomework.data.Story
import homework.chegg.com.chegghomework.data.repositories.DataRepository
import io.reactivex.rxkotlin.Observables
import io.reactivex.subjects.PublishSubject

class DataViewModel(val dataRepository: DataRepository) : ViewModel() {

    var list: PublishSubject<List<Story>> = PublishSubject.create()

    @SuppressLint("CheckResult")
    fun getData() {
        Observables.zip(
                dataRepository.getStories().onErrorReturn { ResponseA() },
                dataRepository.getArticles().onErrorReturn { ResponseB() },
                dataRepository.getArticles2().onErrorReturn { listOf() }
        ) { responseA, responseB, responseC ->
            responseA.stories
            responseB.metadata?.articles

            if (responseA.stories.isNullOrEmpty() ||
                    responseB.metadata?.articles.isNullOrEmpty() ||
                    responseC.isNullOrEmpty()){

            }

            val list = mutableListOf<IDetailsTiDisplay>()
            list.addAll(responseA.stories!!)
            list.addAll(responseB.metadata?.articles!!)
            list.addAll(responseC)

            return@zip list

        }.subscribe {
            it.forEach {
                Log.e("list", it.convertToDisplayObject().title)
            }
        }
    }
}