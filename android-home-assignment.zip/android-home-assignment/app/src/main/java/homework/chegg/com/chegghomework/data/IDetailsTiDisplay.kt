package homework.chegg.com.chegghomework.data

interface IDetailsTiDisplay {
    fun convertToDisplayObject():DetailsTiDisplay
}