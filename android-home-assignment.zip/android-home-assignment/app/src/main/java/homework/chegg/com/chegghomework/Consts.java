package homework.chegg.com.chegghomework;

public class Consts {

    public final static String BASE_URL = "http://chegg-mobile-promotioms.s3.amazonaws.com/android/homework/";

    public final static String DATA_SOURCE_A_URL = "android_homework_datasourceA.json";
    public final static String DATA_SOURCE_B_URL = "android_homework_datasourceB.json";
    public final static String DATA_SOURCE_C_URL = "android_homework_datasourceC.json";

}
